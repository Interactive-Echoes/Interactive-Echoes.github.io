@echo off
setlocal

set "EXE_FILE=IEMidi-1.2.0-win64.exe"
set "EXE_FILE_HASH=Crypto\%EXE_FILE%.sha256"
set "EXE_FILE_HASH_SIGNATURE=%EXE_FILE_HASH%.sig"
set "tempFile=%TEMP%\hash_output.txt"

if not exist "%EXE_FILE%" (
    echo No exe file found, make sure the bat file is placed under the downloaded IE package folder
    echo.
    goto end
)

echo Computing hash for %EXE_FILE%
echo.
powershell -NoProfile -ExecutionPolicy Bypass -Command ^
    "$filePath = '%EXE_FILE%';" ^
    "$hash = Get-FileHash -Path $filePath -Algorithm SHA256;" ^
    "$hash.Hash | Out-File -FilePath '%tempFile%' -Encoding ASCII;"

set /p computedHash=<"%tempFile%"
set /p expectedHash=<"%EXE_FILE_HASH%"

echo Comparing hash vs %EXE_FILE_HASH%
echo.
if "%computedHash%" == "%expectedHash%" (
    echo.|set /p="[32m"  :: Sets text color to green
    echo Hash Match
    echo Computed hash of %EXE_FILE%: %computedHash% equals the expected hash inside %EXE_FILE_HASH%: %expectedHash%
    echo.|set /p="[0m"   :: Resets to default color
) else (
    echo.|set /p="[31m"  :: Sets text color to red
    echo Hash Mismatch
    echo Hash does not match Computed Hash = %computedHash% Expected Hash : %expectedHash%. 
    echo Please contact the original author and do not run the installer %EXE_FILE%
    echo.|set /p="[0m"   :: Resets to default color
)
echo.
del "%tempFile%"

echo Continue to verify signature %EXE_FILE_HASH_SIGNATURE%
echo.
pause

echo.
echo Verifying signature %EXE_FILE_HASH_SIGNATURE% against the file hash %EXE_FILE_HASH%
echo.
ssh-keygen -Y verify -f "Crypto\id_ed25519.pub" -I "mozahzah@users.noreply.github.com" -n file -s "%EXE_FILE_HASH_SIGNATURE%" < "%EXE_FILE_HASH%"
echo.

:end
endlocal
pause